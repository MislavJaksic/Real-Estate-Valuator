## Tests

Tests are used to prove that the system works correctly and if they cannot, tests are used to locate the
error.