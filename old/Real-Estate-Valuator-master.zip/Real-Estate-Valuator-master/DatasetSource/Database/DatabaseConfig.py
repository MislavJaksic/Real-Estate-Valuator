#Absolute path of mongod.exe
dbPath = r"C:\Program Files\MongoDB\Server\3.2\bin\mongod.exe"
#Absolute path to where mongoDB stores the data
dataPath = r"C:\data\db"
#Absolute path of mongo.exe (mongo shell)
mongoShellPath = r"C:\Program Files\MongoDB\Server\3.2\bin\mongo.exe"
#Hostname or IP address or Unix domain socket path of a single mongod
host = r'localhost'
#Port number
port = 27017



