## Input Control

Input Control is responsible for verifying all inputs.

### InputController

Responsibilities: each method verifies a single data type.

The class has no data members and only static methods because the purpose of the class is to package similar
methods.